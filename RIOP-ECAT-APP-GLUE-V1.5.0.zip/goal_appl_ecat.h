/** @file
 *
 * @brief EtherCAT Sample application
 *
 * This application demonstrates the usage of the application callback function.
 *
 * @copyright
 * Copyright 2010-2025.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 *
 * Copyright 2025 NXP
 * NXP Confidential and Proprietary. This software is owned or controlled by NXP
 * and may only be used strictly in accordance with the applicable license
 * terms. By expressly accepting such terms or by downloading, installing,
 * activating and/or otherwise using the software, you are agreeing that you
 * have read, and that you agree to comply with and are bound by, such license
 * terms. If you do not agree to be bound by the applicable license terms, then
 * you may not retain, install, activate or otherwise use the software.
 */


#ifndef GOAL_APPL_ECAT_H
#define GOAL_APPL_ECAT_H


#include "goal_includes.h"
#include "goal_ecat.h"


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T appl_ecatApplInit(
    GOAL_ECAT_T *pHdlEcat                       /**< GOAL EtherCAT handle */
);

GOAL_STATUS_T appl_ecatCallback(
    GOAL_ECAT_T *pHdlEcat,                      /**< GOAL EtherCAT handle */
    GOAL_ECAT_CB_ID_T id,                       /**< callback id */
    GOAL_ECAT_CB_DATA_T *pCb                    /**< callback parameters */
);

#endif /* GOAL_APPL_ECAT_H */
